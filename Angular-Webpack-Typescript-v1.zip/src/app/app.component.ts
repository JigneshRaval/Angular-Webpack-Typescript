import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: `<div>Hello Angular 4</div>`,
    styleUrls: []
}) 
export class AppComponent { }
 